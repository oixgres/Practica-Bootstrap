# Portafolio Utilizando bootstrap

Este portafolio fue creado para un ejemplo de aplicacion de algunos elementos de bootstrap y conocer algunas caracteristicas que se pueden aprovechar.
Este protafolio no se recomienda utilizar para una aplicacion real, ya que solo es un ejemplo ilustrativo debido a que no cuenta con responsive design y mobile design.